﻿from fastapi import FastAPI
from pydantic import BaseModel
import sqlite3
from datetime import datetime
import json

app = FastAPI()


class RobotLocation(BaseModel):
    x: float
    y: float


class AnalysisData(BaseModel):
    person_detected: bool
    fallen_object_detected: bool
    obstacle_detected: bool
    motion_detected: bool
    risk_level: str
    result_summary: str
    analyzed_at: str


class EventData(BaseModel):
    captured_at: str
    robot_location: RobotLocation
    event_type: str
    image_path: str
    analysis: AnalysisData


@app.post("/events")
def save_event(data: EventData):
    conn = sqlite3.connect("autocam_rover.db")
    cur = conn.cursor()

    robot_location_text = json.dumps(
        {
            "x": data.robot_location.x,
            "y": data.robot_location.y
        },
        ensure_ascii=False
    )

    cur.execute("""
    INSERT INTO event_logs (
        captured_at,
        received_at,
        robot_location,
        event_type,
        image_path,
        analysis_status
    )
    VALUES (?, ?, ?, ?, ?, ?)
    """, (
        data.captured_at,
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        robot_location_text,
        data.event_type,
        data.image_path,
        "completed"
    ))

    event_id = cur.lastrowid

    cur.execute("""
    INSERT INTO analysis_results (
        event_id,
        person_detected,
        fallen_object_detected,
        obstacle_detected,
        motion_detected,
        risk_level,
        result_summary,
        analyzed_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        event_id,
        int(data.analysis.person_detected),
        int(data.analysis.fallen_object_detected),
        int(data.analysis.obstacle_detected),
        int(data.analysis.motion_detected),
        data.analysis.risk_level,
        data.analysis.result_summary,
        data.analysis.analyzed_at
    ))

    conn.commit()
    conn.close()

    return {
        "message": "event saved",
        "event_id": event_id
    }

@app.get("/events")
def get_events():
    conn = sqlite3.connect("autocam_rover.db")
    cur = conn.cursor()

    cur.execute("""
    SELECT 
        e.event_id,
        e.captured_at,
        e.robot_location,
        e.event_type,
        e.image_path,
        a.risk_level,
        a.result_summary
    FROM event_logs e
    LEFT JOIN analysis_results a
    ON e.event_id = a.event_id
    ORDER BY e.event_id DESC
    """)

    rows = cur.fetchall()
    conn.close()

    return rows

@app.get("/events/risk/{risk_level}")
def get_events_by_risk(risk_level: str):
    conn = sqlite3.connect("autocam_rover.db")
    cur = conn.cursor()

    cur.execute("""
    SELECT 
        e.event_id,
        e.captured_at,
        e.robot_location,
        e.event_type,
        e.image_path,
        a.risk_level,
        a.result_summary
    FROM event_logs e
    JOIN analysis_results a
    ON e.event_id = a.event_id
    WHERE a.risk_level = ?
    ORDER BY e.event_id DESC
    """, (risk_level,))

    rows = cur.fetchall()
    conn.close()

    return rows
